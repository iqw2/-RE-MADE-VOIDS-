import tkinter as tk
from tkinter import messagebox, filedialog
import socket, ssl, urllib.request, urllib.parse, urllib.error, ipaddress
import json, hashlib, re, os, time, platform, base64
from email.parser import Parser
from email import policy

BG = "#050505"
PANEL = "#0b0b0b"
RED = "#ff1738"
DIM = "#a34a56"
GREEN = "#52ff9b"

NETWORK = [
    ("[01]", "IP DEEP SEARCH"), ("[02]", "URL DEEP SEARCH"),
    ("[03]", "DNS LOOKUP"), ("[04]", "REVERSE DNS"),
    ("[05]", "LOCALHOST PORT CHECK"), ("[06]", "GEOLOCATION"),
    ("[07]", "ASN / RDAP LOOKUP"), ("[08]", "LOCAL NETWORK INFO"),
    ("[09]", "HOST RESOLVE"), ("[10]", "HASH FILE / TEXT"),
]
WEB = [
    ("[11]", "HTTP HEADER CHECK"), ("[12]", "TLS INSPECTOR"),
    ("[13]", "HTTP STATUS"), ("[14]", "REDIRECT CHECK"),
    ("[15]", "SECURITY HEADERS"), ("[16]", "ROBOTS.TXT CHECK"),
    ("[17]", "DNS RECORDS"), ("[18]", "WEB RESPONSE TIME"),
    ("[19]", "URL NORMALIZER"), ("[20]", "DOMAIN INFO"),
]
SECURITY = [
    ("[21]", "EMAIL HEADER ANALYZER"), ("[22]", "PASSWORD STRENGTH"),
    ("[23]", "HASH ANALYZER"), ("[24]", "BASE64 ANALYZER"),
    ("[25]", "JSON INSPECTOR"), ("[26]", "LOG ANALYZER"),
    ("[27]", "STATIC FILE SCAN"), ("[28]", "MALWARE PATTERN ANALYZER"),
    ("[29]", "IP SAFETY CLASSIFICATION"), ("[30]", "ABOUT / HELP"),
]

def fetch(url, timeout=8, limit=200000):
    req = urllib.request.Request(url, headers={"User-Agent": "VOID-TOOLS/2.1 passive defensive analysis"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return {"status": r.status, "headers": dict(r.headers.items()), "url": r.geturl(),
                    "body": r.read(limit).decode("utf-8", "replace")}
    except urllib.error.HTTPError as e:
        return {"status": e.code, "headers": dict(e.headers.items()), "url": e.geturl(),
                "body": e.read(30000).decode("utf-8", "replace")}
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}

def normalize_url(raw):
    raw = raw.strip()
    if not raw:
        raise ValueError("Bitte eine IP, Domain oder URL eingeben.")
    if "://" not in raw:
        raw = "https://" + raw
    p = urllib.parse.urlsplit(raw)
    if not p.hostname:
        raise ValueError("Keine gültige URL oder Domain erkannt.")
    host = p.hostname.encode("idna").decode("ascii").lower()
    netloc = host + (f":{p.port}" if p.port else "")
    return urllib.parse.urlunsplit((p.scheme.lower(), netloc, p.path or "/", p.query, ""))

def resolve(host):
    try:
        return sorted(set(x[4][0] for x in socket.getaddrinfo(host, None)))
    except Exception:
        return []

def dns_info(host):
    lines = []
    ips = resolve(host)
    lines.append("A / AAAA via system resolver: " + (", ".join(ips) if ips else "No results"))
    try:
        name, aliases, addresses = socket.gethostbyaddr(host)
        lines.append("PTR canonical name: " + name)
        lines.append("PTR aliases: " + (", ".join(aliases) if aliases else "none"))
        lines.append("PTR addresses: " + (", ".join(addresses) if addresses else "none"))
    except Exception as e:
        lines.append("PTR: unavailable (" + str(e) + ")")
    return lines

def ip_deep(target):
    out = [f"TARGET: {target}", "=" * 68, "[IDENTIFICATION]"]
    ip = None
    try:
        ip = ipaddress.ip_address(target.strip())
        host = str(ip)
        out += [f"Input Normalized IP: {ip}", f"IP Version: IPv{ip.version}",
                f"Address Family: IPv{ip.version}", f"Public / globally routable: {ip.is_global}",
                f"Private: {ip.is_private}", f"Reserved: {ip.is_reserved}",
                f"Loopback: {ip.is_loopback}", f"Multicast: {ip.is_multicast}",
                f"Link Local: {ip.is_link_local}"]
    except ValueError:
        host = target.strip()
        ips = resolve(host)
        out += [f"Input Hostname: {host}", "Resolved IPs: " + (", ".join(ips) if ips else "none")]
        if ips:
            try:
                ip = ipaddress.ip_address(ips[0])
                out += [f"Primary IP Version: IPv{ip.version}", f"Public / globally routable: {ip.is_global}",
                        f"Private: {ip.is_private}", f"Reserved: {ip.is_reserved}"]
            except ValueError:
                pass
    out += ["", "[DNS / RESOLUTION]"] + dns_info(host)
    out += ["", "[GEOLOCATION / NETWORK / ASN]"]
    if ip:
        geo = fetch("https://ipwho.is/" + str(ip), limit=100000)
        if "body" in geo:
            try:
                d = json.loads(geo["body"])
                for key in ("success", "type", "continent", "continent_code", "country", "country_code",
                            "region", "region_code", "city", "postal", "latitude", "longitude", "is_eu",
                            "calling_code", "capital", "borders"):
                    if key in d:
                        out.append(f"{key}: {d[key]}")
                for section in ("connection", "timezone", "flag"):
                    if isinstance(d.get(section), dict):
                        out.append(section.upper() + ":")
                        out.extend(f"  {k}: {v}" for k, v in d[section].items())
            except Exception:
                out.append("Geo response: " + geo["body"][:3000])
        else:
            out.append("Geo API: " + geo["error"])
        out += ["", "[RDAP / REGISTRATION]"]
        rdap = fetch("https://rdap.org/ip/" + str(ip), timeout=10, limit=250000)
        if "body" in rdap:
            try:
                d = json.loads(rdap["body"])
                for key in ("name", "handle", "type", "country", "startAddress", "endAddress",
                            "ipVersion", "status", "events", "entities", "remarks", "links", "notices"):
                    if key in d:
                        out.append(key + ": " + json.dumps(d[key], ensure_ascii=False, indent=2))
                out += ["", "[RAW RDAP DATA]", json.dumps(d, ensure_ascii=False, indent=2)]
            except Exception:
                out.append(rdap["body"][:5000])
        else:
            out.append("RDAP error: " + rdap["error"])
    else:
        out.append("No IP resolved; Geo/RDAP lookup skipped.")
    out += ["", "[SOURCES]", "System DNS resolver", "ipwho.is public geolocation / network API",
            "rdap.org registry lookup", "Geo-IP is approximate; unavailable fields are not invented."]
    return "\n".join(out)

def url_deep(raw):
    url = normalize_url(raw)
    p = urllib.parse.urlsplit(url)
    host = p.hostname
    out = [f"TARGET: {raw}", f"Normalized URL: {url}", "=" * 68, "[URL IDENTIFICATION]",
           f"Scheme: {p.scheme}", f"Hostname: {host}", f"Port: {p.port or (443 if p.scheme == 'https' else 80)}",
           f"Path: {p.path}", f"Query present: {bool(p.query)}"]
    ips = resolve(host)
    out.append("Resolved addresses: " + (", ".join(ips) if ips else "none"))
    for ip in ips[:4]:
        out += ["", f"[IP DEEP SEARCH: {ip}]", ip_deep(ip)]
    out += ["", "[HTTP RESPONSE / HEADERS / SECURITY]"]
    start = time.perf_counter()
    r = fetch(url, timeout=10)
    out.append(f"Response time: {(time.perf_counter() - start) * 1000:.1f} ms")
    if "error" in r:
        out.append("HTTP error: " + r["error"])
    else:
        out += [f"HTTP status: {r['status']}", f"Final URL: {r['url']}"]
        out += [f"{k}: {v}" for k, v in sorted(r["headers"].items())]
        h = {k.lower(): v for k, v in r["headers"].items()}
        out += ["", "[SECURITY HEADER REVIEW]"]
        for k in ("strict-transport-security", "content-security-policy", "x-content-type-options",
                  "x-frame-options", "referrer-policy", "permissions-policy", "cross-origin-opener-policy"):
            out.append(k + ": " + h.get(k, "MISSING"))
        body = r.get("body", "")
        out += ["", "[HTML / TECHNOLOGY HINTS]"]
        for pattern, label in [(r"<title[^>]*>(.*?)</title>", "Title"),
                               (r"<meta[^>]+name=['\"]generator['\"][^>]+content=['\"]([^'\"]*)", "Generator")]:
            m = re.search(pattern, body, re.I | re.S)
            if m:
                out.append(label + ": " + re.sub(r"\s+", " ", m.group(1))[:300])
        for marker in ("wp-content", "__next", "Drupal.settings", "shopify"):
            if marker.lower() in body.lower():
                out.append("Possible technology marker: " + marker)
    out += ["", "[SOURCES]", "DNS: system resolver", "HTTP: target server response",
            "Passive lookup only; no exploit or intrusive scan."]
    return "\n".join(out)

class VoidTools:
    def __init__(self, root):
        self.root = root
        self.root.title("VOID TOOLS — Passive Cybersecurity Toolkit")
        self.root.geometry("1180x790")
        self.root.minsize(900, 650)
        self.root.configure(bg=BG)
        # Borderless window + custom black title bar avoids the default white Windows frame.
        self.root.overrideredirect(True)
        self.target = tk.StringVar()
        self.selected = tk.StringVar(value="IP DEEP SEARCH")
        self._drag_origin = None
        self.show_splash()

    def add_window_chrome(self, parent):
        bar = tk.Frame(parent, bg=BG, height=30, highlightbackground=RED, highlightthickness=1)
        bar.pack(fill="x", side="top")
        title = tk.Label(bar, text="  ▸ VOID TOOLS  //  PASSIVE CYBERSECURITY TOOLKIT",
                         bg=BG, fg=RED, font=("Consolas", 9, "bold"))
        title.pack(side="left", padx=4)
        close = tk.Button(bar, text=" X ", command=self.root.destroy, bg=BG, fg=RED,
                          activebackground=RED, activeforeground="black",
                          font=("Consolas", 10, "bold"), relief="flat", bd=0)
        close.pack(side="right", padx=3)
        minimize = tk.Button(bar, text=" — ", command=self.minimize_window, bg=BG, fg=RED,
                             activebackground=RED, activeforeground="black",
                             font=("Consolas", 10, "bold"), relief="flat", bd=0)
        minimize.pack(side="right")
        for widget in (bar, title):
            widget.bind("<ButtonPress-1>", self.start_move)
            widget.bind("<B1-Motion>", self.do_move)

    def start_move(self, event):
        self._drag_origin = (event.x_root, event.y_root, self.root.winfo_x(), self.root.winfo_y())

    def do_move(self, event):
        if self._drag_origin:
            x0, y0, wx, wy = self._drag_origin
            self.root.geometry(f"+{wx + event.x_root - x0}+{wy + event.y_root - y0}")

    def minimize_window(self):
        self.root.overrideredirect(False)
        self.root.iconify()
        self.root.after(200, lambda: self.root.overrideredirect(True))

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_splash(self):
        self.clear_window()
        self.add_window_chrome(self.root)
        frame = tk.Frame(self.root, bg=BG, highlightbackground=RED, highlightthickness=2)
        frame.pack(fill="both", expand=True, padx=4, pady=4)
        tk.Label(frame, text="VOID TOOLS", bg=BG, fg=RED,
                 font=("Consolas", 38, "bold")).pack(pady=(65, 8))
        tk.Label(frame, text="P A S S I V E   C Y B E R   I N T E L L I G E N C E",
                 bg=BG, fg=DIM, font=("Consolas", 11)).pack()
        tk.Label(frame, text="my discord: iq_w2", bg=BG, fg=RED,
                 font=("Consolas", 13, "bold")).pack(pady=(8, 38))
        tk.Frame(frame, bg=RED, height=1).pack(fill="x", padx=100)
        tk.Label(frame, text="SECURE ACCESS", bg=BG, fg=RED,
                 font=("Consolas", 18, "bold")).pack(pady=(35, 14))
        tk.Label(frame, text="ENTER ACCESS CODE", bg=BG, fg=DIM,
                 font=("Consolas", 10)).pack()
        self.code = tk.Entry(frame, show="•", justify="center", bg="#101010", fg=RED,
                             insertbackground=RED, font=("Consolas", 22, "bold"),
                             relief="flat", highlightbackground=RED, highlightthickness=1)
        self.code.pack(pady=12, ipady=8)
        self.code.bind("<Return>", lambda event: self.unlock())
        tk.Button(frame, text="INITIALIZE  ▶", command=self.unlock, bg="#31000a", fg=RED,
                  activebackground=RED, activeforeground="black", font=("Consolas", 12, "bold"),
                  relief="flat", padx=45, pady=10).pack(pady=8)
        tk.Label(frame, text="LOCAL UI • PASSIVE LOOKUPS ONLY • AUTHORIZED USE", bg=BG,
                 fg="#74303a", font=("Consolas", 9)).pack(side="bottom", pady=20)
        self.code.focus_set()

    def unlock(self):
        if self.code.get() != "666":
            messagebox.showerror("ACCESS DENIED", "Ungültiger Code.")
            self.code.delete(0, "end")
            self.code.focus_set()
            return
        self.dashboard()

    def dashboard(self):
        self.clear_window()
        self.add_window_chrome(self.root)
        header = tk.Frame(self.root, bg=BG, highlightbackground=RED, highlightthickness=1)
        header.pack(fill="x", padx=10, pady=8)
        tk.Label(header, text="▸ VOID TOOLS v2.1", bg=BG, fg=RED,
                 font=("Consolas", 13, "bold")).pack(side="left", padx=12, pady=8)
        tk.Label(header, text="my discord: iq_w2", bg=BG, fg=DIM,
                 font=("Consolas", 10)).pack(side="right", padx=12)
        logo = (
            "  __      __   ____   ___  ____    _________   ____   ____  ",
            "  \\ \\    / /  / __ \\ /   |/ __ \\  /_  __/   / __ \\ / __ \\ ",
            "   \\ \\  / /  / / / // /| / / / /   / /     / / / // / / / ",
            "    \\ \\/ /  / /_/ // ___ / /_/ /   / /    / /_/ // /_/ /  ",
            "     \\__/   \\____//_/  |_/____/   /_/     \\____/ \\____/   ",
        )
        for line in logo:
            tk.Label(self.root, text=line, bg=BG, fg=RED,
                     font=("Consolas", 11, "bold"), anchor="center").pack(fill="x", pady=0)
        tk.Label(self.root, text="T O O L K I T   •   my discord: iq_w2",
                 bg=BG, fg=RED, font=("Consolas", 9, "bold")).pack(pady=(1, 6))
        panels = tk.Frame(self.root, bg=BG)
        panels.pack(fill="x", padx=9)
        for title, tools in [("NETWORK INTELLIGENCE", NETWORK), ("WEB INTELLIGENCE", WEB),
                             ("SECURITY ANALYSIS", SECURITY)]:
            box = tk.Frame(panels, bg=PANEL, highlightbackground=RED, highlightthickness=1)
            box.pack(side="left", fill="both", expand=True, padx=4)
            tk.Label(box, text=title, bg=PANEL, fg=RED,
                     font=("Consolas", 10, "bold")).pack(anchor="w", padx=7, pady=7)
            for number, name in tools:
                tk.Button(box, text=f"{number} {name}", anchor="w",
                          command=lambda n=name: self.choose(n), bg=PANEL, fg="#ff5268",
                          activebackground="#35000a", activeforeground="white",
                          font=("Consolas", 8), relief="flat", cursor="hand2").pack(fill="x", padx=4, pady=1)
        area = tk.Frame(self.root, bg=BG)
        area.pack(fill="x", padx=15, pady=8)
        tk.Label(area, text="TARGET URL / IP / TEXT / FILE PATH:", bg=BG, fg=RED,
                 font=("Consolas", 9, "bold")).pack(anchor="w")
        self.entry = tk.Entry(area, textvariable=self.target, bg="#101010", fg=RED,
                              insertbackground=RED, font=("Consolas", 10), relief="flat",
                              highlightbackground=RED, highlightthickness=1)
        self.entry.pack(fill="x", ipady=6, pady=3)
        row = tk.Frame(area, bg=BG)
        row.pack(fill="x")
        tk.Label(row, text="SELECTED:", bg=BG, fg=RED, font=("Consolas", 9)).pack(side="left")
        self.tool_label = tk.Label(row, text=self.selected.get(), bg=BG, fg=GREEN,
                                   font=("Consolas", 9, "bold"))
        self.tool_label.pack(side="left", padx=8)
        tk.Button(row, text="RUN TOOL", command=self.run_tool, bg="#31000a", fg=RED,
                  activebackground=RED, relief="flat", font=("Consolas", 10, "bold"),
                  padx=18).pack(side="right")
        tk.Button(row, text="CHOOSE FILE", command=self.choose_file, bg="#151515", fg=RED,
                  relief="flat", padx=10).pack(side="right", padx=5)
        tk.Button(row, text="CLEAR", command=lambda: self.show_results("Results cleared."),
                  bg="#151515", fg=RED, relief="flat", padx=12).pack(side="right", padx=5)
        self.output = tk.Text(self.root, bg="#030303", fg="#ff5268", insertbackground=RED,
                              font=("Consolas", 9), wrap="word", relief="flat",
                              highlightbackground=RED, highlightthickness=1)
        self.output.pack(fill="both", expand=True, padx=15, pady=(0, 8))
        self.show_results("VOID TOOLS READY\nChoose a tool, enter a target, then RUN TOOL.\n")
        tk.Label(self.root, text="PASSIVE ANALYSIS ONLY • AUTHORIZED USE", bg=BG, fg=RED,
                 font=("Consolas", 9, "bold")).pack(pady=(0, 7))

    def choose(self, name):
        self.selected.set(name)
        self.tool_label.config(text=name)
        if name in ("STATIC FILE SCAN", "MALWARE PATTERN ANALYZER", "LOG ANALYZER", "HASH FILE / TEXT"):
            self.entry.focus_set()

    def choose_file(self):
        path = filedialog.askopenfilename(title="Choose a file for local analysis")
        if path:
            self.target.set(path)

    def show_results(self, text):
        self.output.config(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("end", text)
        self.output.config(state="disabled")

    def run_tool(self):
        name = self.selected.get()
        target = self.target.get().strip()
        try:
            result = self.execute(name, target)
        except Exception as exc:
            result = f"ERROR: {type(exc).__name__}: {exc}"
        self.show_results(result)

    def execute(self, name, target):
        if name == "IP DEEP SEARCH" or name in ("DNS LOOKUP", "ASN / RDAP LOOKUP", "IP SAFETY CLASSIFICATION"):
            return ip_deep(target)
        if name == "URL DEEP SEARCH":
            return url_deep(target)
        if name in ("REVERSE DNS", "HOST RESOLVE", "DNS RECORDS"):
            return "\n".join(dns_info(target))
        if name == "LOCAL NETWORK INFO":
            out = [f"Hostname: {socket.gethostname()}", f"Platform: {platform.platform()}"]
            try:
                out.append("Local IP: " + socket.gethostbyname(socket.gethostname()))
            except Exception as e:
                out.append("Local IP: " + str(e))
            return "\n".join(out)
        if name == "LOCALHOST PORT CHECK":
            out = ["SAFE LOOPBACK CHECK: 127.0.0.1", "Only localhost is checked."]
            for port in (21, 22, 25, 53, 80, 135, 139, 443, 445, 3306, 3389, 5000, 5432, 8000, 8080, 8443):
                s = socket.socket()
                s.settimeout(0.15)
                try:
                    if s.connect_ex(("127.0.0.1", port)) == 0:
                        out.append(f"OPEN {port}")
                finally:
                    s.close()
            return "\n".join(out + ["Check complete."])
        if name in ("HTTP HEADER CHECK", "HTTP STATUS", "REDIRECT CHECK", "SECURITY HEADERS", "WEB RESPONSE TIME", "TECHNOLOGY HINTS"):
            url = normalize_url(target)
            start = time.perf_counter()
            r = fetch(url, timeout=10)
            elapsed = (time.perf_counter() - start) * 1000
            out = [f"URL: {url}", f"Final URL: {r.get('url', 'n/a')}",
                   f"HTTP status: {r.get('status', 'n/a')}", f"Response time: {elapsed:.1f} ms"]
            if "error" in r:
                out.append(r["error"])
            else:
                if name in ("HTTP HEADER CHECK", "SECURITY HEADERS"):
                    out += ["", "[HEADERS]"] + [f"{k}: {v}" for k, v in sorted(r["headers"].items())]
                if name == "SECURITY HEADERS":
                    h = {k.lower(): v for k, v in r["headers"].items()}
                    out += ["", "[SECURITY HEADER REVIEW]"]
                    for k in ("strict-transport-security", "content-security-policy", "x-content-type-options",
                              "x-frame-options", "referrer-policy", "permissions-policy"):
                        out.append(k + ": " + h.get(k, "MISSING"))
                if name == "REDIRECT CHECK":
                    out.append("Redirects followed by standard library; final URL shown above.")
                if name == "TECHNOLOGY HINTS":
                    body = r.get("body", "")
                    out.append("Possible HTML markers: " + ", ".join(x for x in ("wp-content", "__next", "shopify", "Drupal.settings") if x in body))
            return "\n".join(out)
        if name == "TLS INSPECTOR":
            p = urllib.parse.urlsplit(normalize_url(target))
            with socket.create_connection((p.hostname, p.port or 443), timeout=8) as sock:
                with ssl.create_default_context().wrap_socket(sock, server_hostname=p.hostname) as ss:
                    cert = ss.getpeercert()
                    return "\n".join([f"Host: {p.hostname}", f"TLS version: {ss.version()}",
                                      f"Cipher: {ss.cipher()}", f"Subject: {cert.get('subject')}",
                                      f"Issuer: {cert.get('issuer')}", f"Valid until: {cert.get('notAfter')}",
                                      f"SAN: {cert.get('subjectAltName')}"])
        if name == "ROBOTS.TXT CHECK":
            p = urllib.parse.urlsplit(normalize_url(target))
            r = fetch(f"{p.scheme}://{p.netloc}/robots.txt")
            return f"Status: {r.get('status', r.get('error'))}\n\n{r.get('body', '')[:15000]}"
        if name == "URL NORMALIZER":
            return normalize_url(target)
        if name == "DOMAIN INFO":
            p = urllib.parse.urlsplit(normalize_url(target))
            return "\n".join([f"Hostname: {p.hostname}", f"Scheme: {p.scheme}", f"Port: {p.port}", f"Path: {p.path}"] + dns_info(p.hostname))
        if name == "GEOLOCATION":
            try:
                ip = str(ipaddress.ip_address(target))
            except ValueError:
                ip = socket.gethostbyname(target)
            r = fetch("https://ipwho.is/" + ip)
            return json.dumps(json.loads(r["body"]), ensure_ascii=False, indent=2) if "body" in r else r["error"]
        if name == "HASH FILE / TEXT" or name == "HASH ANALYZER":
            if os.path.isfile(target):
                h = hashlib.sha256()
                with open(target, "rb") as f:
                    for chunk in iter(lambda: f.read(1024 * 1024), b""):
                        h.update(chunk)
                return f"File: {target}\nSize: {os.path.getsize(target)} bytes\nSHA-256: {h.hexdigest()}"
            data = target.encode()
            return "\n".join(f"{alg.upper()}: {getattr(hashlib, alg)(data).hexdigest()}" for alg in ("md5", "sha1", "sha256", "sha512"))
        if name == "BASE64 ANALYZER":
            return base64.b64decode(target, validate=True).decode("utf-8", "replace")
        if name == "JSON INSPECTOR":
            return json.dumps(json.loads(target), ensure_ascii=False, indent=2, sort_keys=True)
        if name == "EMAIL HEADER ANALYZER":
            msg = Parser(policy=policy.default).parsestr(target)
            out = [f"{k}: {v}" for k, v in msg.items()]
            out += ["", f"Received hops: {len(msg.get_all('Received', []))}",
                    "SPF: " + str(msg.get("Received-SPF", "not present")),
                    "Authentication-Results: " + str(msg.get("Authentication-Results", "not present")),
                    "Note: email headers can be forged; this is not a definitive verdict."]
            return "\n".join(out)
        if name == "PASSWORD STRENGTH":
            score = sum((len(target) >= n) for n in (8, 12, 16, 20)) + sum(bool(re.search(p, target)) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
            return f"Length: {len(target)}\nCharacter groups: {sum(bool(re.search(p, target)) for p in (r'[a-z]',r'[A-Z]',r'\d',r'[^A-Za-z0-9]'))}/4\nHeuristic score: {score}/8\nDo not reuse passwords; this score is only a rough local estimate."
        if name in ("LOG ANALYZER", "STATIC FILE SCAN", "MALWARE PATTERN ANALYZER"):
            if not os.path.isfile(target):
                return "Enter a local file path or use CHOOSE FILE. File is read only and never executed."
            if os.path.getsize(target) > 20 * 1024 * 1024:
                return "Safety limit: maximum file size is 20 MiB."
            with open(target, "rb") as f:
                data = f.read()
            txt = data.decode("utf-8", "replace")
            if name == "LOG ANALYZER":
                patterns = (("Errors", r"\b(error|fatal|exception)\b"), ("Auth failures", r"failed login|authentication failure|401|403"),
                            ("Suspicious input", r"\.\./|union select|<script|powershell"))
                out = [f"File: {target}", f"Lines: {len(txt.splitlines())}"]
                for label, pattern in patterns:
                    hits = [f"{i+1}: {line[:250]}" for i, line in enumerate(txt.splitlines()) if re.search(pattern, line, re.I)]
                    out += ["", f"{label}: {len(hits)}"] + hits[:80]
                return "\n".join(out)
            signatures = {"EICAR test marker": b"EICAR-STANDARD-ANTIVIRUS-TEST-FILE",
                          "PowerShell hint": b"powershell", "Download command hint": b"curl http",
                          "Script eval hint": b"eval("}
            return "\n".join(["STATIC ONLY — file was not executed", f"File: {target}", f"Size: {len(data)} bytes",
                              "SHA-256: " + hashlib.sha256(data).hexdigest()] +
                             [k + ": " + ("MATCH" if v.lower() in data.lower() else "no match") for k, v in signatures.items()] +
                             ["Heuristic matches are not proof of malware."])
        if name == "WAYBACK SEARCH":
            r = fetch("https://web.archive.org/cdx/search/cdx?url=" + urllib.parse.quote(target, safe="") + "&output=json&filter=statuscode:200&fl=timestamp,original,statuscode", timeout=10)
            return r.get("body", r.get("error", "No response"))
        if name == "ABOUT / HELP":
            return "VOID TOOLS v2.1\nCode: 666\nPassive defensive lookups only.\nIP Deep Search uses DNS, public Geo-IP and RDAP where available.\nURL Deep Search includes resolved IP lookups, HTTP response, headers and visible technology hints.\nPort check is restricted to 127.0.0.1."
        return "This tool is not implemented yet."

if __name__ == "__main__":
    root = tk.Tk()
    app = VoidTools(root)
    root.mainloop()
