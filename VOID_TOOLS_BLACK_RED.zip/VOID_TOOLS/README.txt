VOID TOOLS — BLACK UI EDITION
==============================

STARTEN
1. ZIP-Datei entpacken.
2. Ordner VOID_TOOLS in Visual Studio Code öffnen.
3. Terminal → Neues Terminal.
4. Ausführen:
       python iqw2_dox.py
   Alternativ:
       py iqw2_dox.py

Beim Start erscheint die schwarze VOID-TOOLS-Zugangsseite.
Zugangscode: 666 (Enter drücken).
Danach erscheint das Dashboard mit drei Tool-Bereichen.

DESIGN-ÄNDERUNGEN
- Schwarze Benutzeroberfläche und schwarzer eigener Fensterrand/Titelleiste.
- Rote, kantige ASCII-Banner-Schrift im Dashboard.
- Discord-Text: iq_w2.

VORAUSSETZUNGEN
- Python 3.10+ mit Tkinter.
- Keine zusätzlichen pip-Pakete nötig.
- Bei Startproblemen in VS Code testen:
       python --version
       python -m tkinter

SICHERHEIT
Das Tool ist für defensive, passive Lookups gedacht. Der Port-Check prüft nur 127.0.0.1.
Datei-Analyse liest Dateien statisch und führt sie nicht aus. IP-/Geo-/RDAP-Angaben hängen
von öffentlichen Diensten ab und können unvollständig oder ungenau sein.
Der Code 666 ist nur ein einfacher UI-Zugangscode, keine echte Authentifizierung.
